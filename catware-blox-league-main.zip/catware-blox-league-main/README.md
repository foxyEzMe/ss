# Catware for Blox League

*The most powerful bot for* **[Blox League](https://www.roblox.com/games/118675786171302)**. Built on [Obsidian UI](https://docs.mspaint.cc/obsidian/installation/executor) and tested on [Volt](https://docs.voltbz.net).

| Main | Visuals | UI Settings |
|:---:|:---:|:---:|
| ![Main tab](assets/catware-main.svg) | ![Visuals tab](assets/catware-visuals.svg) | ![UI Settings tab](assets/catware-ui-settings.svg) |

~~Grind ranked for months~~. Catware runs **Nexto**, a Grand Champion-level Rocket League neural network, directly inside Roblox. It doesn't chase the ball like a script. It reads the whole field and plays: rotations, dribbles, flicks, aerials and kickoffs.

---

## Why it's the strongest

Blox League is a faithful Luau port of RocketSim, the physics engine Rocket League bots are trained in. Catware feeds the live match state straight into Nexto, so the network plays the game it was trained on.

- **Real neural network, not if-statements.** Nexto was trained with deep reinforcement learning and reached about GC1 in 1s, 2s and 3s against real Rocket League players.
- **Bit-exact port.** The Luau inference and inputs were checked against the original PyTorch model: same action on every test, logits within 1e-5.
- **Live results (public 3v3, 90 s):**
  - **29 touches** against **25 for the other five players combined**
  - **1 goal for, 0 against**
  - Dribble into a flick at **2840 uu/s**, and aerial touches up to **862 uu**
- **Free play:** 3 goals a minute, every touch on target.
- **Smooth frames.** Inference is spread across frames (about 4 ms a slice), so no stutter.

---

## Features

- **Nexto bot** (`N`): full autopilot, including Nexto's scripted speed-kickoff when you're the kickoff taker
- **Ball prediction**: the ball's future path and next bounce, drawn in the world using the game's own physics
- **Boost ESP**: boost amount above every car, teammates blue and opponents orange
- **Assists** when you drive yourself:
  - Auto flip into the ball
  - Auto air recovery
- **Auto-load after teleport**: Catware comes along from the lobby into matches and back
- **Catppuccin** theme by default; configs and themes saved per game

---

## Getting started

1. Run this in your executor while in Blox League (lobby, free play or a match):
   ```lua
   loadstring(game:HttpGet("https://gitlab.com/azulacs/catware-blox-league/-/raw/main/catware.lua"))()
   ```
2. `RightShift` toggles the menu.
3. In the lobby, turn on **UI Settings → Menu → Auto-load after teleport** so Catware follows you into matches.
4. Press `N` in a match or free play and watch Nexto play.

On first run Catware downloads the Nexto model (~2.4 MB) and caches it in `Catware/BloxLeague/` in your executor workspace.

---

## Good to know

- The game is **server-authoritative**. Catware only sends controller inputs, the same way a player does, so the server accepts them. There are no speed or teleport hacks for it to reject.
- Nexto plays at a level real players notice. A public lobby losing to a bot that out-touches everyone can get reported. Use it at your own risk.
- It needs an executor with `queue_on_teleport`, `crypt.base64decode` and the Drawing library. Built and tested on **Volt**.

---

## Credits & license

- **Nexto** by Rolv, Soren, and several contributors (as credited in its RLBot config), from [Necto](https://github.com/Rolv-Arild/Necto). The model is theirs; `nexto.lua` is a Luau port of it, and `nexto_weights.lua` holds its weights.
- [Obsidian UI](https://github.com/deividcomsono/Obsidian) by deivid.
- Because Nexto is licensed under **CC BY-NC-SA 4.0**, so is this project: see [LICENSE](LICENSE). Credit the authors, don't use it commercially, and share adaptations under the same terms.
